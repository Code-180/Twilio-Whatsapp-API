require('dotenv').config()
const axios = require('axios');
const express = require('express');
const client = require('twilio')(process.env.SID, process.env.TOKEN);
const MessagingResponse = require('twilio').twiml.MessagingResponse;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const app = express()
const port = 3000
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.post('/sendMessage', (req, res) => {
    client.messages.create({
        body: 'Your appointment is coming up on August 20 at 4PM',
        from: 'whatsapp:+14155238886',
        to: 'whatsapp:+919163331565'
    }).then(message => res.send(message));
})
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.post('/resiveMessage', async (req, res) => {
    console.log(res.body);
})
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.post('/resiveMessageStatus', async (req, res) => {
    console.log(res.body);
})
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})




